from django.urls import path
from .views import UserListView, UserDetailView, MovieListView
from django.contrib import admin
from django.urls import path, include
from .views import (
    UserListView, UserDetailView, SignupView, LoginView, MovieListView, UserFavoriteListView
)
from .views import TokenTestView
urlpatterns = [
    path('api/user/', UserListView.as_view(), name='user_list'),
    path('api/user/<int:id>/', UserDetailView.as_view(), name='user_detail'),
    path('api/auth/signup/', SignupView.as_view(), name='signup'),
    path('api/auth/login/', LoginView.as_view(), name='login'),
    path('api/title/', MovieListView.as_view(), name='movie_list'),
    path('api/user/<int:id>/list/add/', UserFavoriteListView.as_view(), name='user_favorites_add'),

    path('api/test-token/', TokenTestView.as_view(), name='test_token'),

    path('api/user/<int:id>/list/', UserFavoriteListView.as_view(), name='user_favorites'),
]


