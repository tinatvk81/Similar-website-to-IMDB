from django.contrib import admin
from .models import Genre, Movie, Celebrity, Comment, UserProfile, UserMovie, Watchlist
from django.contrib.auth.admin import UserAdmin
from .models import UserProfile

admin.site.register(Genre)
admin.site.register(Movie)
admin.site.register(Celebrity)
admin.site.register(Comment)
# admin.site.register(UserProfile)
admin.site.register(UserMovie)
admin.site.register(Watchlist)

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import UserProfile


@admin.register(UserProfile)
class CustomUserAdmin(UserAdmin):
    list_display = ('username', 'email', 'is_staff', 'is_superuser', 'is_active')
    list_filter = ('is_staff', 'is_superuser', 'is_active')
    search_fields = ('username', 'email')
    ordering = ('username',)


# @admin.register(UserProfile)
# class CustomUserAdmin(UserAdmin):
#     list_display = ('username', 'email', 'is_staff', 'is_active')
#     list_filter = ('is_staff', 'is_active')
#     search_fields = ('username', 'email')
#     ordering = ('username',)
#     fieldsets = UserAdmin.fieldsets + (
#         (None, {'fields': ('token', 'watch_list', 'favorites')}),
#     )
#     add_fieldsets = UserAdmin.add_fieldsets + (
#         (None, {'fields': ('token',)}),
#     )

# try:
#     admin.site.register(UserProfile, UserAdmin)
# except admin.sites.AlreadyRegistered:
#     pass