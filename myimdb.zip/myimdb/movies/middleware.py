# from django.http import JsonResponse

# class AdminRequiredMiddleware:
#     def __init__(self, get_response):
#         self.get_response = get_response

#     def __call__(self, request):
#         print(f"User: {request.user}")  # دیباگ نام کاربر
#         print(f"Authenticated: {request.user.is_authenticated}")  # بررسی احراز هویت
#         print(f"Staff: {request.user.is_staff}")  # بررسی وضعیت ادمین
#         if request.path.startswith('/api/user/') and not (request.user and request.user.is_authenticated and request.user.is_staff):
#             return JsonResponse({'error': 'Admin access required','d':request.user.username,'s':request.user.is_authenticated ,'a':request.user.is_staff}, status=403)
#         return self.get_response(request)
from django.http import JsonResponse
from rest_framework_simplejwt.authentication import JWTAuthentication

class AdminRequiredMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.path.startswith('/admin/'):
            return self.get_response(request)
        
        jwt_authenticator = JWTAuthentication()
        try:
            if request.path.startswith('/api/user/'):
            
                auth_header = request.headers.get('Authorization')
                if auth_header is None:
                    return JsonResponse({'error': 'No Authorization header provided'}, status=401)
                
                token = auth_header.split()[1] 
                validated_token = jwt_authenticator.get_validated_token(token)
                user = jwt_authenticator.get_user(validated_token)

               
                request.user = user
                
                allowed_paths = [
                    f'/api/user/{user.id}/list/',  
                    f'/api/user/{user.id}/list/add/',  
                    f'/api/user/{user.id}/',  
                ]
                
               
                if request.path in allowed_paths:
                    return self.get_response(request)

                if not (user.is_authenticated and user.is_staff):
                    return JsonResponse({
                        'error': 'Admin access required',
                        'user': user.username,
                        'is_authenticated': user.is_authenticated,
                        'is_staff': user.is_staff
                    }, status=403)

        except Exception as e:
   
            return JsonResponse({'error': str(e)}, status=403)

        return self.get_response(request)
