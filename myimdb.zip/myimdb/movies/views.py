from django.shortcuts import render
from django.contrib.auth import authenticate
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.pagination import PageNumberPagination
from .models import Movie, UserProfile
from .serializers import UserProfileSerializer, MovieSerializer
from .permissions import IsAdminUser, IsSelfOrAdmin
from django.shortcuts import get_object_or_404
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.permissions import IsAdminUser
from django.contrib.auth.hashers import make_password

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework_simplejwt.authentication import JWTAuthentication

class TokenTestView(APIView):
    def get(self, request):
        jwt_authenticator = JWTAuthentication()
        try:
          
            auth_header = request.headers.get('Authorization')
            if auth_header is None:
                return Response({'error': 'No Authorization header provided'}, status=401)
            
            token = auth_header.split()[1] 
            validated_token = jwt_authenticator.get_validated_token(token)
            user = jwt_authenticator.get_user(validated_token)

            return Response({
                'user': user.username,
                'is_authenticated': user.is_authenticated,
                'is_staff': user.is_staff,
            })
        except Exception as e:
            return Response({'error': str(e)}, status=400)


class UserFavoriteListView(APIView):
    def post(self, request, id):
        user = get_object_or_404(UserProfile, id=id)
        movie_id = request.data.get('movie_id')  
        movie = get_object_or_404(Movie, id=movie_id)

        user.favorites.add(movie)
        return Response({'message': 'Movie added to favorites'}, status=status.HTTP_201_CREATED)
    
class UserDetailView(APIView):
    permission_classes = []#IsAdminUser

    def get(self, request, id):
        user = get_object_or_404(UserProfile, id=id)
        serializer = UserProfileSerializer(user)
        return Response(serializer.data)

    def delete(self, request, id):
        user = get_object_or_404(UserProfile, id=id)
        user.delete()
        return Response({'message': 'User deleted successfully'}, status=status.HTTP_204_NO_CONTENT)

    def put(self, request, id):
        user = get_object_or_404(UserProfile, id=id)
        if not (request.user.is_staff or request.user.id == id):
            return Response({'error': 'Unauthorized'}, status=status.HTTP_403_FORBIDDEN)
        serializer = UserProfileSerializer(user, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


from rest_framework.permissions import IsAdminUser
from rest_framework.views import APIView
from rest_framework.response import Response
from .models import UserProfile
from .serializers import UserProfileSerializer

class UserListView(APIView):
    permission_classes = [IsAdminUser]

    def get(self, request):
        print(request.user)  
        print(request.user.is_staff) 
        print("Is Authenticated:", request.user.is_authenticated)
        users = UserProfile.objects.all()
        serializer = UserProfileSerializer(users, many=True)
        return Response(serializer.data)


class SignupView(APIView):
    permission_classes = [] 

    def post(self, request):
        username = request.data.get('username')
        password = request.data.get('password')

        if UserProfile.objects.filter(username=username).exists():
            return Response({'error': 'Username already exists'}, status=400)

        user = UserProfile.objects.create(
            username=username,
            password=make_password(password) 
        )
        return Response({'message': 'User created successfully'}, status=201)


class LoginView(APIView):
    permission_classes = []  

    def post(self, request):
        username = request.data.get('username')
        password = request.data.get('password')
        user = authenticate(username=username, password=password)

        if user is not None:
            refresh = RefreshToken.for_user(user)
            return Response({
                'refresh': str(refresh),
                'access': str(refresh.access_token),
            })
        else:
            return Response({'error': 'Invalid credentials'}, status=401)

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import authenticate


class MovieListView(APIView):
    def get(self, request):
        paginator = PageNumberPagination()
        paginator.page_size = int(request.GET.get('count', 10))
        movies = Movie.objects.all()
        result_page = paginator.paginate_queryset(movies, request)
        serializer = MovieSerializer(result_page, many=True)
        return paginator.get_paginated_response(serializer.data)


class UserFavoriteListView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, id):
        user = get_object_or_404(UserProfile, id=id)
        favorites = user.favorites.all()
        serializer = MovieSerializer(favorites, many=True)
        return Response(serializer.data)

    def post(self, request, id):
        user = get_object_or_404(UserProfile, id=id)
        movie_id = request.data.get('movie_id')
        movie = get_object_or_404(Movie, id=movie_id)
        user.favorites.add(movie)
        return Response({'message': 'Movie added to favorites'}, status=status.HTTP_201_CREATED)
