from django.db import models
from django.utils.crypto import get_random_string
import uuid
from django.contrib.auth.models import AbstractUser
from django.utils.timezone import now


class Genre(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Movie(models.Model):
    TYPE_CHOICES = (
        ('movie', 'Movie'),
        ('series', 'Series'),
    )
    imdb_id = models.CharField(max_length=10, unique=True)
    title = models.CharField(max_length=255)
    description = models.TextField()
    release_date = models.DateField()
    rating = models.FloatField(default=0.0)
    type = models.CharField(max_length=10, choices=TYPE_CHOICES)
    genres = models.ManyToManyField(Genre, related_name='movies')

    def __str__(self):
        return self.title


class GenreMovie(models.Model):
    genre = models.ForeignKey(Genre, on_delete=models.CASCADE)
    movie = models.ForeignKey(Movie, on_delete=models.CASCADE)

    class Meta:
        unique_together = ('genre', 'movie')

    def __str__(self):
        return f"{self.movie.title} - {self.genre.name}"


class Celebrity(models.Model):
    name = models.CharField(max_length=255)
    birthdate = models.DateField(null=True, blank=True)

    def __str__(self):
        return self.name


class MovieCelebrity(models.Model):
    movie = models.ForeignKey(Movie, on_delete=models.CASCADE)
    celebrity = models.ForeignKey(Celebrity, on_delete=models.CASCADE)
    role = models.CharField(max_length=255)

    class Meta:
        unique_together = ('movie', 'celebrity')

    def __str__(self):
        return f"{self.celebrity.name} in {self.movie.title} as {self.role}"


class Trailer(models.Model):
    movie = models.ForeignKey(Movie, on_delete=models.CASCADE, related_name='trailers')
    url = models.URLField()

    def __str__(self):
        return f"Trailer for {self.movie.title}"


class Comment(models.Model):
    user = models.ForeignKey('UserProfile', on_delete=models.CASCADE, related_name='comments')
    movie = models.ForeignKey(Movie, on_delete=models.CASCADE, related_name='comments')
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'Comment by {self.user.username} on {self.movie.title}'


# def generate_token():
#     return get_random_string(64)  


def generate_token():
    return str(uuid.uuid4())

from django.contrib.auth.models import AbstractUser
from django.db import models
import uuid

class UserProfile(AbstractUser):
    token = models.CharField(max_length=64, unique=True, default=uuid.uuid4)
    watch_list = models.ManyToManyField('Movie', related_name='watchers', blank=True)
    favorites = models.ManyToManyField('Movie', related_name='favorited_by', blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.username


class UserMovie(models.Model):
    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE, related_name='user_movies')
    movie = models.ForeignKey(Movie, on_delete=models.CASCADE, related_name='user_movies')
    rating = models.FloatField(null=True, blank=True)
    watched_status = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'movie')

    def __str__(self):
        return f"{self.user.username} - {self.movie.title} - Rated: {self.rating}"


class Watchlist(models.Model):
    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE, related_name='watchlist')
    movie = models.ForeignKey(Movie, on_delete=models.CASCADE, related_name='watchlisted_by')
    rating = models.FloatField(null=True, blank=True)
    added_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'movie')

    def __str__(self):
        return f"{self.user.username}'s Watchlist: {self.movie.title}"


class UserMovieRelation(models.Model):
    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE)
    movie = models.ForeignKey(Movie, on_delete=models.CASCADE)
    rating = models.FloatField(null=True, blank=True)
    watched = models.BooleanField(default=False)
    added_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'movie')

    def __str__(self):
        return f'{self.user.username} - {self.movie.title}'
